﻿namespace first
{
    partial class JoinForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(JoinForm));
            this.emailBox = new System.Windows.Forms.TextBox();
            this.passWordBox = new System.Windows.Forms.TextBox();
            this.guna2GradientCircleButton1 = new Guna.UI2.WinForms.Guna2GradientCircleButton();
            this.AgreeButton = new Guna.UI2.WinForms.Guna2GradientCircleButton();
            this.guna2GradientCircleButton2 = new Guna.UI2.WinForms.Guna2GradientCircleButton();
            this.FirstNameBox = new System.Windows.Forms.TextBox();
            this.lastNameBox = new System.Windows.Forms.TextBox();
            this.guna2GradientCircleButton3 = new Guna.UI2.WinForms.Guna2GradientCircleButton();
            this.guna2GradientCircleButton4 = new Guna.UI2.WinForms.Guna2GradientCircleButton();
            this.showButton = new Guna.UI2.WinForms.Guna2GradientCircleButton();
            this.UserDG = new Guna.UI2.WinForms.Guna2DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.UserDG)).BeginInit();
            this.SuspendLayout();
            // 
            // emailBox
            // 
            this.emailBox.BackColor = System.Drawing.Color.White;
            this.emailBox.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.emailBox.Location = new System.Drawing.Point(583, 181);
            this.emailBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.emailBox.Name = "emailBox";
            this.emailBox.Size = new System.Drawing.Size(310, 30);
            this.emailBox.TabIndex = 0;
            // 
            // passWordBox
            // 
            this.passWordBox.BackColor = System.Drawing.Color.White;
            this.passWordBox.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.passWordBox.ForeColor = System.Drawing.Color.Black;
            this.passWordBox.Location = new System.Drawing.Point(583, 244);
            this.passWordBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.passWordBox.Name = "passWordBox";
            this.passWordBox.Size = new System.Drawing.Size(310, 30);
            this.passWordBox.TabIndex = 1;
            // 
            // guna2GradientCircleButton1
            // 
            this.guna2GradientCircleButton1.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientCircleButton1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2GradientCircleButton1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2GradientCircleButton1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2GradientCircleButton1.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2GradientCircleButton1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2GradientCircleButton1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.guna2GradientCircleButton1.ForeColor = System.Drawing.Color.Black;
            this.guna2GradientCircleButton1.Location = new System.Drawing.Point(294, 232);
            this.guna2GradientCircleButton1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.guna2GradientCircleButton1.Name = "guna2GradientCircleButton1";
            this.guna2GradientCircleButton1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2GradientCircleButton1.Size = new System.Drawing.Size(159, 57);
            this.guna2GradientCircleButton1.TabIndex = 4;
            this.guna2GradientCircleButton1.Text = "PassWord";
            // 
            // AgreeButton
            // 
            this.AgreeButton.BackColor = System.Drawing.Color.Transparent;
            this.AgreeButton.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.AgreeButton.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.AgreeButton.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.AgreeButton.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.AgreeButton.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.AgreeButton.FillColor = System.Drawing.Color.Blue;
            this.AgreeButton.FillColor2 = System.Drawing.Color.Blue;
            this.AgreeButton.Font = new System.Drawing.Font("Sitka Small", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.AgreeButton.ForeColor = System.Drawing.Color.White;
            this.AgreeButton.Location = new System.Drawing.Point(484, 349);
            this.AgreeButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.AgreeButton.Name = "AgreeButton";
            this.AgreeButton.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.AgreeButton.Size = new System.Drawing.Size(212, 86);
            this.AgreeButton.TabIndex = 6;
            this.AgreeButton.Text = "Agree & Join";
            this.AgreeButton.Click += new System.EventHandler(this.guna2GradientCircleButton3_Click);
            // 
            // guna2GradientCircleButton2
            // 
            this.guna2GradientCircleButton2.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientCircleButton2.Font = new System.Drawing.Font("Sitka Small", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.guna2GradientCircleButton2.ForeColor = System.Drawing.Color.Black;
            this.guna2GradientCircleButton2.Location = new System.Drawing.Point(294, 32);
            this.guna2GradientCircleButton2.Name = "guna2GradientCircleButton2";
            this.guna2GradientCircleButton2.Size = new System.Drawing.Size(159, 60);
            this.guna2GradientCircleButton2.TabIndex = 0;
            this.guna2GradientCircleButton2.Text = "First Name";
            // 
            // FirstNameBox
            // 
            this.FirstNameBox.Location = new System.Drawing.Point(583, 43);
            this.FirstNameBox.Name = "FirstNameBox";
            this.FirstNameBox.Size = new System.Drawing.Size(310, 31);
            this.FirstNameBox.TabIndex = 7;
            this.FirstNameBox.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lastNameBox
            // 
            this.lastNameBox.Location = new System.Drawing.Point(583, 114);
            this.lastNameBox.Name = "lastNameBox";
            this.lastNameBox.Size = new System.Drawing.Size(310, 31);
            this.lastNameBox.TabIndex = 8;
            // 
            // guna2GradientCircleButton3
            // 
            this.guna2GradientCircleButton3.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientCircleButton3.Font = new System.Drawing.Font("Sitka Small", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.guna2GradientCircleButton3.ForeColor = System.Drawing.Color.Black;
            this.guna2GradientCircleButton3.Location = new System.Drawing.Point(294, 98);
            this.guna2GradientCircleButton3.Name = "guna2GradientCircleButton3";
            this.guna2GradientCircleButton3.Size = new System.Drawing.Size(159, 60);
            this.guna2GradientCircleButton3.TabIndex = 9;
            this.guna2GradientCircleButton3.Text = "Last Name";
            // 
            // guna2GradientCircleButton4
            // 
            this.guna2GradientCircleButton4.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientCircleButton4.Font = new System.Drawing.Font("Sitka Small", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.guna2GradientCircleButton4.ForeColor = System.Drawing.Color.Black;
            this.guna2GradientCircleButton4.Location = new System.Drawing.Point(294, 164);
            this.guna2GradientCircleButton4.Name = "guna2GradientCircleButton4";
            this.guna2GradientCircleButton4.Size = new System.Drawing.Size(159, 60);
            this.guna2GradientCircleButton4.TabIndex = 10;
            this.guna2GradientCircleButton4.Text = "Email";
            // 
            // showButton
            // 
            this.showButton.BackColor = System.Drawing.Color.Transparent;
            this.showButton.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.showButton.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.showButton.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.showButton.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.showButton.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.showButton.FillColor = System.Drawing.Color.Blue;
            this.showButton.FillColor2 = System.Drawing.Color.Blue;
            this.showButton.Font = new System.Drawing.Font("Sitka Small", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.showButton.ForeColor = System.Drawing.Color.White;
            this.showButton.Location = new System.Drawing.Point(40, 337);
            this.showButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.showButton.Name = "showButton";
            this.showButton.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.showButton.Size = new System.Drawing.Size(250, 90);
            this.showButton.TabIndex = 11;
            this.showButton.Text = "Show All Sign_Up User";
            this.showButton.Click += new System.EventHandler(this.showButton_Click);
            // 
            // UserDG
            // 
            this.UserDG.AllowUserToAddRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.UserDG.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.UserDG.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.UserDG.ColumnHeadersHeight = 4;
            this.UserDG.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.UserDG.DefaultCellStyle = dataGridViewCellStyle3;
            this.UserDG.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.UserDG.Location = new System.Drawing.Point(989, 224);
            this.UserDG.Name = "UserDG";
            this.UserDG.RowHeadersVisible = false;
            this.UserDG.RowHeadersWidth = 62;
            this.UserDG.RowTemplate.Height = 33;
            this.UserDG.Size = new System.Drawing.Size(612, 417);
            this.UserDG.TabIndex = 12;
            this.UserDG.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.UserDG.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.UserDG.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.UserDG.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.UserDG.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.UserDG.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.UserDG.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.UserDG.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.UserDG.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.UserDG.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.UserDG.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.UserDG.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.UserDG.ThemeStyle.HeaderStyle.Height = 4;
            this.UserDG.ThemeStyle.ReadOnly = false;
            this.UserDG.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.UserDG.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.UserDG.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.UserDG.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.UserDG.ThemeStyle.RowsStyle.Height = 33;
            this.UserDG.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.UserDG.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            // 
            // JoinForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1613, 674);
            this.Controls.Add(this.UserDG);
            this.Controls.Add(this.showButton);
            this.Controls.Add(this.guna2GradientCircleButton4);
            this.Controls.Add(this.guna2GradientCircleButton3);
            this.Controls.Add(this.lastNameBox);
            this.Controls.Add(this.FirstNameBox);
            this.Controls.Add(this.guna2GradientCircleButton2);
            this.Controls.Add(this.AgreeButton);
            this.Controls.Add(this.guna2GradientCircleButton1);
            this.Controls.Add(this.passWordBox);
            this.Controls.Add(this.emailBox);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "JoinForm";
            this.Text = "JoinForm";
            ((System.ComponentModel.ISupportInitialize)(this.UserDG)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox emailBox;
        private TextBox passWordBox;
        private Guna.UI2.WinForms.Guna2GradientCircleButton guna2GradientCircleButton1;
        private Guna.UI2.WinForms.Guna2GradientCircleButton AgreeButton;
        private Guna.UI2.WinForms.Guna2GradientCircleButton guna2GradientCircleButton2;
        private TextBox FirstNameBox;
        private TextBox lastNameBox;
        private Guna.UI2.WinForms.Guna2GradientCircleButton guna2GradientCircleButton3;
        private Guna.UI2.WinForms.Guna2GradientCircleButton guna2GradientCircleButton4;
        private Guna.UI2.WinForms.Guna2GradientCircleButton showButton;
        private Guna.UI2.WinForms.Guna2DataGridView UserDG;
    }
}