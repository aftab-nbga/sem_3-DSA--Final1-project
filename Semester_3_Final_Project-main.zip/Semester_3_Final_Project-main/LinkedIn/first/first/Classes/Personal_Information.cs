﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace first.Classes
{
    public class Personal_Information
    {
        public string email;
        public string passWord;
        public string firstName;
        public string lastName;
    }
}
